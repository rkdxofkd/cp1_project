import jwt
import time


METABASE_SITE_URL = "http://localhost:3000"
METABASE_SECRET_KEY = "c964c6ff05c0f79553345dc1f9d7b0f45df639c3c7c6c42e1c0c98149dd63848"

payload = {
  "resource": {"dashboard": 1},
  "params": {
    
  },
  "exp": round(time.time()) + (60 * 10) # 10 minute expiration
}
token = jwt.encode(payload, METABASE_SECRET_KEY, algorithm="HS256")

iframeUrl = METABASE_SITE_URL + "/embed/dashboard/" + token + "#bordered=true&titled=true"




print(iframeUrl)