import psycopg2 as pg2
import pandas as pd

#from sqlalchemy import create_engine


# engine = create_engine("postgresql://postgres:y1025405@localhost:5432/project_db")




df = pd.read_csv('C:/Users/coding/Desktop/cp1/data/seoul_permission_info_1.csv')
# def eda_1(df):
#데이터 저장 변환해서 해야함
#필요한 것만 추출(관리번호,인허가일자, 영업상태코드, 상세영업코드, 상세영업상태, 폐업일자, 지번주소, 사업자명, 도로명주소, 소재지우편번호, 지번주소, 업태구분명, 좌표정보(X), 좌표정조(Y), 다중이용업소여부 )
#관리번호 기준으로 원래 데이터와 조사용 데이터 구분
df_origin = df[['관리번호','인허가일자',  '상세영업상태코드',
    '상세영업상태명', '폐업일자', '소재지우편번호', '지번주소', '도로명주소', 
    '업태구분명', '좌표정보(X)', '좌표정보(Y)', '위생업태명', '다중이용업소여부', '시설총규모']]
df_dash= df_origin[['관리번호','상세영업상태코드','상세영업상태명','소재지우편번호','업태구분명']]
#아이디로 관리번호 사용할 예정
df_origin['관리번호'] = df_origin['관리번호'].astype(str).str.replace('-','', regex=True)
#괄호제거
df_origin.rename(columns={'좌표정보(X)': '좌표정보_X', '좌표정보(Y)': '좌표정보_Y'}, inplace=True)

#주소- 서울특별시 제거 & 어느 구인지 컬럼 따로 만들기
df_dash['지역구'] = df_origin['지번주소'].str.split(" ").str[1]
df_dash['지역동'] = df_origin['지번주소'].str.split(" ").str[2]
df_origin['지번주소']= df_origin['지번주소'].str.replace("서울특별시", "")
df_origin['도로명주소']=df_origin['도로명주소'].str.replace("서울특별시", "")


#허가 &폐업일자 년-월/일로 나누기
df_dash['인허가일자_년']=df_origin['인허가일자'].astype(str).str.slice(start=0,stop=4)
df_dash['인허가일자_월']=df_origin['인허가일자'].astype(str).str.slice(start=4,stop=6)
df_dash['인허가일자_년']=df_dash['인허가일자_년'].astype(int)
df_dash['인허가일자_월']=df_dash['인허가일자_월'].astype(int)
df_dash['폐업_년']=df_origin['폐업일자'].fillna('0'*8)
df_dash['폐업_월']=df_origin['폐업일자'].fillna('0'*8)
df_dash['폐업_년']=df_dash['폐업_년'].astype(str).str.slice(start=0,stop=4)
df_dash['폐업_월']=df_dash['폐업_월'].astype(str).str.slice(start=4,stop=6)
df_dash['폐업_년']=df_dash['폐업_년'].astype(int)
df_dash['폐업_월']=df_dash['폐업_월'].astype(int)

#postgresql 연결

print(df_dash['인허가일자_년'])
print(df_dash['폐업_월'])

conn = pg2.connect(
    host="localhost",
    database="cp_1_1",
    user="postgres",
    password='y1025405',
    port=5432
)

# conn = engine.connect()
conn.autocommit = True
cur = conn.cursor()



cur.execute("DROP TABLE IF EXISTS origin_data;")

# 원하는 컬럼에 대한 table형성
origin ="""CREATE TABLE origin_data(
관리번호 VARCHAR(2048) PRIMARY KEY,
인허가일자 VARCHAR(2048),
상세영업상태코드 INT,
상세영업상태명 CHAR(20),
폐업일자 CHAR(20),
소재지우편번호 CHAR(20),
지번주소 VARCHAR(2048),
도로명주소 VARCHAR(2048),
업태구분명 CHAR(20),
좌표정보_X NUMERIC,
좌표정보_Y NUMERIC,
위생업태명 CHAR(20),
다중이용업소여부 CHAR(20),
시설총규모 NUMERIC);"""
cur.execute(origin)



for index,row in df_origin.iterrows():
    cur.execute("INSERT INTO origin_data (관리번호,인허가일자,상세영업상태코드,상세영업상태명,폐업일자,소재지우편번호,지번주소,도로명주소,업태구분명,좌표정보_X,좌표정보_Y,위생업태명,다중이용업소여부,시설총규모) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
    (row.관리번호,row.인허가일자, row.상세영업상태코드, row.상세영업상태명, row.폐업일자, row.소재지우편번호, row.지번주소, row.도로명주소,  row.업태구분명, row.좌표정보_X, row.좌표정보_Y, row.위생업태명, row.다중이용업소여부, row.시설총규모))
conn.commit()

cur.execute("DROP TABLE IF EXISTS exp_data;")

# 원하는 컬럼에 대한 table형성
exp ="""CREATE TABLE exp_data(
관리번호 VARCHAR(2048) PRIMARY KEY,
상세영업상태코드 INT,
상세영업상태명 CHAR(20),
소재지우편번호 CHAR(20),
업태구분명 CHAR(20),
지역구 CHAR(20),
지역동 CHAR(20),
인허가일자_년 INT,
인허가일자_월 INT,
폐업_년 INT,
폐업_월 INT
);"""

cur.execute(exp)
for index,row in df_dash.iterrows():
    cur.execute("INSERT INTO exp_data (관리번호,상세영업상태코드,상세영업상태명, 소재지우편번호, 업태구분명, 지역구, 지역동, 인허가일자_년, 인허가일자_월,폐업_년,폐업_월) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
    (row.관리번호,row.상세영업상태코드,row.상세영업상태명, row.소재지우편번호, row.업태구분명, row.지역구, row.지역동, row.인허가일자_년, row.인허가일자_월, row.폐업_년,row.폐업_월))

conn.commit()

conn.close()
print('hi')