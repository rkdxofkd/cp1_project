from flask import Flask 

def create_app():
    app = Flask(__name__)

    from .sol import route
    app.register_blueprint(route.bp)


    return app



#앱 실행 전 flask 세팅 해줘야 한다 (export FLASK_APP=food_industry, export FLASK_ENV=develoment)
#환경변수 확인(printenv FLASK_APP/FLASK_ENV)