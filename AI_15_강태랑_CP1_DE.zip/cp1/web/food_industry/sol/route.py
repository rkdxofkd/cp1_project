from flask import Blueprint ,render_template, Flask, request
import jwt
import time
import pickle
# import find_place
# from data_extract2 import answer_list 


#metabase url, key
METABASE_SITE_URL= "http://localhost:3000"
METABASE_SECRET_KEY="c964c6ff05c0f79553345dc1f9d7b0f45df639c3c7c6c42e1c0c98149dd63848"


# with open('data_extract2.pickle','rb') as f:
#     dfs= pickle.load(f)


# df_s = dfs[0]
# df_l = dfs[1]

# metabase question을 넣을 수 있도록 반복
def input_series(a):
    payload = {
    "resource": {"question": a},
    "params": { 
        
    },
    "exp": round(time.time()) + (60 * 10) # 10 minute expiration
    }
    token = jwt.encode(payload, METABASE_SECRET_KEY, algorithm="HS256")
    iframeUrl = METABASE_SITE_URL + "/embed/question/" + token + "#theme=night&bordered=true&titled=true"
    return iframeUrl



bp = Blueprint('main', __name__, url_prefix='/')

    #시작 페이지에서 상권 분석 or 지역 찾기를 선택하도록 요구
@bp.route('/')
def index():
    return render_template('index.html')



#상권 분석에서는 한해동안 서울 외식업 상황(개업 위치, 폐업 위치, 음식점 많은 곳, 어떤 음식점 많은지)
@bp.route('/dash_1', methods=('POST','GET'))
def dashboard_1():
    question_34= input_series(34) #지역구 전체
    question_7= input_series(7) #상위 음식점 종류
    question_6= input_series(6) #하위 음식점 종류
    question_33 = input_series(33) #음식점 유지기간(망했을시)

    return render_template('dash_1.html', question_34=question_34,
     question_7=question_7, question_6=question_6, question_33=question_33)




@bp.route('/dash_2', methods=('POST','GET'))
def dashboard_2():
    question_35=input_series(35) #2022년 지역별 음식점 개업 위치
    question_5=input_series(5) #2022년 폐업한 음식점 위치
    question_8= input_series(8) #2022년 상위 10개 음식점 개업
    question_9= input_series(9) #2022년 하위 10개 음식점 개업
    question_10= input_series(10) #2022년 폐업한 음식점 종류


    return render_template('dash_2.html',question_35=question_35 ,question_5=question_5,
    question_8=question_8,question_9=question_9,question_10=question_10)

# @bp.route('/dash_3', methods=('POST','GET'))
# def dashboard_3():
#     METABASE_SITE_URL = "http://localhost:3000"

#     return render_template('dash_3.html', iframeUrl=iframeUrl)



#나에게 맞는 개업 위치 찾기
@bp.route('/store', methods=('POST','GET'))
def store_where():

    return render_template('store.html')


    # age = request.form.get("age")
    # money = request.form.get("money")
    # store_scale = request.form.get("store_scale")
    # scale_num = request.form.get("scale_num")
    # answer=answer_list(store_scale, scale_num, money)


#추가적으로 개업 위치를 찾을 때 나이& 금액에 대한 데이터를 적재-> 현재 원하는 사람들 표본군을 얻기
#추가적으로 원하는 요식업이 있다=> 어떤 위치가 좋을지 고려(경쟁 음식점이 많은 곳과 없는 곳을 보여줌)
#추가적으로 인구수 or 위치에 따른 비율도 고려하면 좋음