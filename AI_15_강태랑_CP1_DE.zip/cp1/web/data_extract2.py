import pandas as pd 
import pickle 


#소규모 상가 & 중대형 상가 임대료 
df_s = pd.read_csv('C:/Users/coding/Desktop/cp1/data/rent_per_s.csv', encoding='cp949')
df_l = pd.read_csv('C:/Users/coding/Desktop/cp1/data/rent_per_l.csv', encoding='cp949')
def eda(df):
    df = df[df['상권별(1)']=='서울']
    df = df[df['상권별(2)']!='서울']
    df =df.drop(columns=['상권별(1)'])
    df = df.rename(columns={'상권별(2)':'상권별','상권별(3)':'위치'})
    return df


df_s = eda(df_s)
df_l = eda(df_l)

dfs=[df_s,df_l]
with open('data_extract2.pickle', 'wb') as fw:
    for i in dfs:
        pickle.dump(i, fw)

a = 0 #소규모 상가 or 중대형 상가
b = 0 #원하는 평수 or m^2
c = 0 #갖고있는 금액

# def answer_list(a,b,c):
#     answer =dict({})

#     if a == '소규모 상가':
#         for index,row in df_s.iterrows():
#             if b == '평':
#                 b = b*3.305785
#             else:
#                 b=b
#             if row['2022.3/4']*round(b,2) < c:
#                 answer[row['위치']]=row['2022.3/4'
                
#     elif a=='중규모 상가':
#         for index,row in df_l.iterrows():
#             if b == '평':
#                 b= b*3.305785
#             else:
#                 b=b
#             if float(row['2022.3/4'])*round(b,2) <= c:
#                 answer[row['위치'],row['층구분별(1)']]=row['2022.3/4']
#     return answer

# df_answer = answer_list(a)

#먼저 원하는 평 or 현재 금액-> 추천 위치
#해야 할 것 
# 1) 소규모 상가 or 중대형 상가 선택을 하도록 요구
# 2)원하는 평수 or 평방미터 (if 평수라면 평방미터로 변환)
# 3) 가능한 위치를 말해줌(if 중대형 경우, 층수 고려) 
# 4) 원하는 data로 머신러닝 만든 후 피클링해서 ->웹사이트에 배포

# +추가적으로 docker 진행해서 대시보드 꼭 만들자 -> 웹에 임베딩
# +프랜차이즈별 