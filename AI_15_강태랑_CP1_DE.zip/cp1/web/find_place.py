import pandas as pd 
import pickle
with open('data_extract2.pickle','rb') as f:
    dfs= pickle.load(f)

df_s=dfs[0]
df_l=dfs[1]

class find_place:
    def __init__(self):
        

        a = 0 #소규모 상가 or 중대형 상가
        b = 0 #원하는 평수 or m^2
        c = 0 #갖고있는 금액`

    def answer_list(a):
        answer =dict({})

        if a == '소규모 상가':
            for index,row in df_s.iterrows():

                if row['2022.3/4']*b < c:
                    answer[row['위치']]=row['2022.3/4']

        elif a=='중규모 상가':
            for index,row in df_l.iterrows():

                if float(row['2022.3/4']) <= float(c):
                    answer[row['위치'],row['층구분별(1)']]=row['2022.3/4']
        return answer

df_answer = answer_list(a)

















