import pandas as pd 



#소규모 상가 & 중대형 상가 임대료 
df_s = pd.read_csv('C:/Users/coding/Desktop/cp1/data/rent_per_s.csv', encoding='cp949')
df_l = pd.read_csv('C:/Users/coding/Desktop/cp1/data/rent_per_l.csv', encoding='cp949')
def eda(df):
    df = df[df['상권별(1)']=='서울']
    df = df[df['상권별(2)']!='서울']
    df =df.drop(columns=['상권별(1)'])
    df = df.rename(columns={'상권별(2)':'상권별','상권별(3)':'위치'})
    return df


df_s = eda(df_s)
df_l = eda(df_l)

print(df_l)